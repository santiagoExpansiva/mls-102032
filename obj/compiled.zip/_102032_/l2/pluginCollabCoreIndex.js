/// <mls fileReference="_102032_/l2/pluginCollabCoreIndex.ts" enhancement="_blank"/>
import { PluginBaseIndex } from '/_100554_/l2/pluginBaseIndex.js';
export class PluginCollabCoreIndex extends PluginBaseIndex {
    getMenus() {
        return [
            {
                category: 'Helpers',
                scope: ['l5Project'],
                priority: 1,
                auth: ['*'],
                widget: '_102032_/plugins/pluginTranslate'
            },
        ];
    }
    getHooks() {
        return [];
    }
    getServices() {
        return [];
    }
}
export default new PluginCollabCoreIndex();
